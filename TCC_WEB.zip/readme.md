## Integrantes

- Brenno Flora da Silva - Developer?
- Daniel Lourenço Macedo - Developer
- Fernando Keller Haddad - Developer
- Guilherme Santos Pagliarini - Developer 
- Tiago Melo Belém - Scrum Master

## Ferramentas 
- GitHub
- Excel 
   
## Sprint

- Modelagem Infra / Persistência
    - Criação das models, e definir as regras de negócio
- Features por tipo de usuário
    - Executor
        - Home / Login
        - Cadastrar Evento 
        - Cancelar Evento
        - Enviar e-mail para eventos que foram comprados porém cancelados oferecendo reembolso
    - Gerente
        - Aprovar / Reprovar Eventos
        - Relatório de Eventos
    - Usuário Comum
        - Caso não possua mais ingressos colocar usuário em fila de espera
        - Cancelar compra e quando cancelar enviar email falando que foi liberado para o primeiro da fila