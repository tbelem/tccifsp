package br.edu.ifsp.model;

import com.google.firebase.database.Exclude;

/**
 * Created by Tiago on 30/10/2017.
 */

public class Alternativa {

    private int ID;
    private String texto;
    
    private long resultTotal;
    private float resultPercent;

    public Alternativa(int pID, String pTexto){
        this.ID = pID;
        this.texto = pTexto;
        this.resultTotal = 0;
        this.resultPercent = 0;
    }

    @Exclude
    public int getID() { return ID;  }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    @Exclude
    public long getResultTotal() {
		return resultTotal;
	}

	public void setResultTotal(long resultTotal) {
		this.resultTotal = resultTotal;
	}

	@Exclude
	public float getResultPercent() {
		return resultPercent;
	}

	public void setResultPercent(float resultPercent) {
		this.resultPercent = resultPercent;
	}  
    
}
