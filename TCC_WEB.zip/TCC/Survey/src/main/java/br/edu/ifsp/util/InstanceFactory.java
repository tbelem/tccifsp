package br.edu.ifsp.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseCredentials;
import com.google.firebase.database.FirebaseDatabase;


public final class InstanceFactory {

    private static FirebaseAuth firebaseAuth;
    private static FirebaseDatabase firebaseDatabase;
    private static FileInputStream serviceAccount;
	private static FirebaseOptions options;
    
    public static void startDatabase() {
    	
    	if (options == null) {
    	
			try {
				
				serviceAccount = new FileInputStream("C:\\Users\\Tiago\\eclipse-workspace\\TCC\\Survey\\firebaseSDKacc.json");
				
				options = new FirebaseOptions.Builder()
						  .setCredential(FirebaseCredentials.fromCertificate(serviceAccount))
						  .setDatabaseUrl("https://tccifsp-d646a.firebaseio.com/")
						  .build();
				
				FirebaseApp.initializeApp(options);
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
    	}
    	
    }

    public static FirebaseAuth getAuthInstance(){

        if (firebaseAuth == null){
        	startDatabase();
            firebaseAuth = FirebaseAuth.getInstance();
        }

        return firebaseAuth;
    }

    public static FirebaseDatabase getDBInstance(){

        if (firebaseDatabase == null){
        	startDatabase();
            firebaseDatabase = FirebaseDatabase.getInstance();
        }

        return firebaseDatabase;
    }

}
