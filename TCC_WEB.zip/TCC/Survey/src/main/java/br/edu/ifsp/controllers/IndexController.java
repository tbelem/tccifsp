package br.edu.ifsp.controllers;

import java.util.ArrayList;

import javax.inject.Inject;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.validator.Validator;
import br.edu.ifsp.model.Admin;
import br.edu.ifsp.model.Questionario;
import br.edu.ifsp.session.UsuarioSession;
import br.edu.ifsp.util.InstanceFactory;
import br.edu.ifsp.util.DateConverter;

@Controller
public class IndexController {
	
	@Inject
	private UsuarioSession usuarioSession;
	
	@Inject
	private Result result;
	
	@Inject
	private Validator validator;
	
	private Admin finded;
	
	private int returnStatus = 0;
	private String returnMessage = "";
	
	@Path("/index")
	public void index() {
		
		if(! usuarioSession.isLogado()) {
			result.redirectTo(LoginController.class).login();
		}		
		else {
			
			FirebaseDatabase db = InstanceFactory.getDBInstance();
			
			ArrayList<Questionario> questionarios = new ArrayList<>();
			
			db.getReference("questionarios").orderByChild("owner").equalTo(usuarioSession.getId())
			  .addListenerForSingleValueEvent(new ValueEventListener() {
				
				@Override
				public void onDataChange(DataSnapshot arg0) {
					
					if (arg0 != null){
						for (DataSnapshot row : arg0.getChildren()){
							
							Questionario aux = row.getValue(Questionario.class);
							aux.setId(row.getKey());
							aux.setStringInicio(DateConverter.timestampToStringDate(aux.getInicio()));
							aux.setStringFim(DateConverter.timestampToStringDate(aux.getFim()));
							
							questionarios.add(aux);
		                }						
		            }
					
					returnStatus = 1;
					
				}
				
				@Override
				public void onCancelled(DatabaseError arg0) {
					returnStatus = 2;
				}
			});
			
			
			while (returnStatus == 0) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			result.include("questionarios", questionarios);
			
		}	
		
	}
	

}
