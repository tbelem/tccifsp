package br.edu.ifsp.model;

import com.google.firebase.database.Exclude;

/**
 * Created by Tiago on 19/10/2017.
 */

public class Questionario {

    private String id;
    private String nome;
    private String descricao;
    private long inicio;
    private long fim;
    private int recompensa;
    private String owner;    

	private String stringInicio;
    private String stringFim;

    public Questionario() {
    }

    public Questionario(String id, long inicio, long fim, int recompensa) {
        this.id = id;
        this.inicio = inicio;
        this.fim = fim;
        this.recompensa = recompensa;
    }

    public String getDescricao() { return descricao; }

    public void setDescricao(String descricao) { this.descricao = descricao; }

    @Exclude
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public long getInicio() {
        return inicio;
    }

    public void setInicio(long inicio) {
        this.inicio = inicio;
    }

    public long getFim() {
        return fim;
    }

    public void setFim(long fim) {
        this.fim = fim;
    }

    public int getRecompensa() {
        return recompensa;
    }

    public void setRecompensa(int recompensa) {
        this.recompensa = recompensa;
    }
    
    public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	@Exclude
	public String getStringInicio() {
		return stringInicio;
	}

	public void setStringInicio(String stringInicio) {
		this.stringInicio = stringInicio;
	}

	@Exclude
	public String getStringFim() {
		return stringFim;
	}

	public void setStringFim(String stringFim) {
		this.stringFim = stringFim;
	}

    public String toString (){
        return "id: " + id + " | inicio: " + String.valueOf(inicio) + " | fim: " + String.valueOf(fim) + " | rec: " + String.valueOf(recompensa) + " | sInicio: " + stringInicio + " | sFim: " + stringFim;
    }
}
