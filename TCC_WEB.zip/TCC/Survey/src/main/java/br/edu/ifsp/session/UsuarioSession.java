package br.edu.ifsp.session;

import java.io.Serializable;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import br.edu.ifsp.model.Admin;

@SessionScoped
@Named("sessao")
public class UsuarioSession implements Serializable{
	private static final long serialVersionUID = -2883031389844933915L;
	
	private Admin logado;
	
	public void login(Admin usuario) {
		this.logado = usuario;
	}
	  
	public String getEmail() {
		return logado.getEmail();
	}
	
	public String getId() {
		return logado.getUID();
	}
	  
	public boolean isLogado() {
		return logado != null;
	}
	
	public void logout() {
		this.logado = null;
	}
}
