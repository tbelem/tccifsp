package br.edu.ifsp.controllers;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Path;

@Controller
public class TesteController {
	
	@Path("/")
	public void teste() {
		
	}
}
