package br.edu.ifsp.controllers;

import javax.inject.Inject;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserRecord;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.tasks.OnCompleteListener;
import com.google.firebase.tasks.Task;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Post;
import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.validator.SimpleMessage;
import br.com.caelum.vraptor.validator.Validator;
import br.edu.ifsp.model.Admin;
import br.edu.ifsp.model.Usuario;
import br.edu.ifsp.session.UsuarioSession;
import br.edu.ifsp.util.InstanceFactory;

@Controller
public class LoginController {
	
	@Inject
	private UsuarioSession usuarioSession;
	
	@Inject
	private Result result;
	
	@Inject
	private Validator validator;
	
	private Admin finded;
	
	private int returnStatus = 0;
	private String returnMessage = "";
	
	@Path("/login")
	public void login() {
		
		if(usuarioSession.isLogado()) {
			result.redirectTo(IndexController.class).index();
		}
		
	}
	
	@Path("/logout")
	public void logout() {
		if(usuarioSession.isLogado()) {
			usuarioSession.logout();
		}
		result.redirectTo(LoginController.class).login();
	}
	
	@Post
	@Path("/login/autenticar")
	public void autenticar(String email, String senha) {
		
		finded = new Admin("","");
		
		final String paramEmail = email;
		final String paramSenha = senha;
		
		if (paramEmail == null) {
			validator.add(new SimpleMessage("Preencha o email !", "usuario.email"));
		}
		
		if (paramSenha == null) {
			validator.add(new SimpleMessage("Preencha a senha !", "usuario.senha"));
		}
		
		validator.onErrorUsePageOf(LoginController.class).login();
		
		FirebaseAuth auth = InstanceFactory.getAuthInstance();
		
		Task<UserRecord> task = auth.getUserByEmail(paramEmail).addOnCompleteListener(new OnCompleteListener<UserRecord>() {			
				@Override
				public void onComplete(Task<UserRecord> arg0) {
					
						if(arg0.isSuccessful()) {
							finded.setUID(arg0.getResult().getUid());
							
							FirebaseDatabase db = InstanceFactory.getDBInstance();
							
							db.getReference("admin").child(finded.getUID()).child("password")
								.addListenerForSingleValueEvent(new ValueEventListener() {
									
									@Override
									public void onDataChange(DataSnapshot arg0) {

										if (paramSenha.equals(arg0.getValue())) {
											finded.setEmail(paramEmail);
											returnStatus = 1;
										}
										else {
											returnStatus = 2;
											returnMessage = "Login ou senha inválidos";
										}
										
									}
									
									@Override
									public void onCancelled(DatabaseError arg0) {
										returnStatus = 2;
										returnMessage = "Login ou senha inválidos";
									}
									
							});
							
						}
						
						else {
							returnStatus = 2;
							returnMessage = "Login ou senha inválidos";
						}
				}
			});
		
		
		while (returnStatus == 0){
			System.out.println("Segurando...");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (returnStatus == 1) {
			usuarioSession.login(finded);
			result.redirectTo(IndexController.class).index();
		}
		else {
			validator.add(new SimpleMessage(returnMessage, "usuario.email"));
			validator.onErrorUsePageOf(LoginController.class).login();
		}
		
		
		/*Usuario carregado;// = dao.findByEmail(usuario.getUsu_email());
		
		if (carregado == null) {
			validator.add(new SimpleMessage("Login ou senha inválidos", "usuario.login"));
		} else {
			String str = usuario.getUsu_senha();
			if(!str.equals(carregado.getUsu_senha())) {
				validator.add(new SimpleMessage("Login ou senha inválidos", "usuario.senha"));
			}
		}
		
		validator.onErrorUsePageOf(LoginController.class).login();
		
		usuarioSession.login(carregado);
		result.redirectTo(IndexController.class).index();*/
	}

}
