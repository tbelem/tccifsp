package br.edu.ifsp.controllers;

import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;

import javax.inject.Inject;
import javax.servlet.ServletContext;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PieLabelLinkStyle;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.title.LegendTitle;
import org.jfree.data.general.DefaultPieDataset;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Path;
import br.com.caelum.vraptor.Result;
import br.com.caelum.vraptor.validator.Validator;
import br.edu.ifsp.model.Admin;
import br.edu.ifsp.model.Alternativa;
import br.edu.ifsp.model.Questao;
import br.edu.ifsp.model.Questionario;
import br.edu.ifsp.session.UsuarioSession;
import br.edu.ifsp.util.DateConverter;
import br.edu.ifsp.util.InstanceFactory;
import br.edu.ifsp.util.GlobalValues;

@Controller
public class ConsultaController {
	
	@Inject
	private UsuarioSession usuarioSession;
	
	@Inject
	private Result result;
	
	@Inject
	private Validator validator;
	
	@Inject
	private ServletContext context;
	
	private Admin finded;
	
	private int returnStatus = 0;
	private String returnMessage = "";
	
	private Questionario retorno;
	private ArrayList<Questao> questoes;
	
	@Get("/consulta/questionario/{quest_id}")
	public void consultaQuestionarios(String quest_id) {		
		
		if(! usuarioSession.isLogado()) {
			result.redirectTo(LoginController.class).login();
		}		
		else {
			
			returnStatus = 0;
			returnMessage = "";
			
			FirebaseDatabase db = InstanceFactory.getDBInstance();
			
			retorno = new Questionario();
			
			db.getReference("questionarios").child(quest_id)
			  .addListenerForSingleValueEvent(new ValueEventListener() {
				
				@Override
				public void onDataChange(DataSnapshot arg0) {
					retorno = arg0.getValue(Questionario.class);
					retorno.setId(arg0.getKey());
					retorno.setStringInicio(DateConverter.timestampToStringDate(retorno.getInicio()));
					retorno.setStringFim(DateConverter.timestampToStringDate(retorno.getFim()));
					
					returnStatus = 1;
				}
				
				@Override
				public void onCancelled(DatabaseError arg0) {
					returnStatus = 2;					
				}
			});			
			
			while (returnStatus == 0) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			result.include("quest", retorno);
			
		}		
	}
	
	
	@Get("/consulta/resultado/{quest_id}")
	public void consultaResultado(String quest_id) {		
		
		if(! usuarioSession.isLogado()) {
			result.redirectTo(LoginController.class).login();
		}		
		else {
			
			returnStatus = 0;
			returnMessage = "";
			
			FirebaseDatabase db = InstanceFactory.getDBInstance();
			
			questoes = new ArrayList<>();
			
			retorno = new Questionario();
			
			db.getReference("questionarios").child(quest_id)
			  .addListenerForSingleValueEvent(new ValueEventListener() {
				
				@Override
				public void onDataChange(DataSnapshot arg0) {
					retorno = arg0.getValue(Questionario.class);
					retorno.setId(arg0.getKey());
					retorno.setStringInicio(DateConverter.timestampToStringDate(retorno.getInicio()));
					retorno.setStringFim(DateConverter.timestampToStringDate(retorno.getFim()));
				}
				
				@Override
				public void onCancelled(DatabaseError arg0) {
					returnStatus = 2;					
				}
			});
			
			db.getReference("questoes").child(quest_id)
			  .addListenerForSingleValueEvent(new ValueEventListener() {
				
				@Override
				public void onDataChange(DataSnapshot arg0) {
					
					for (DataSnapshot row : arg0.getChildren()) {
						System.out.println("Troca questao: " + row.getKey());
						Questao quesAux = row.getValue(Questao.class);
						quesAux.setSequence(Integer.parseInt(row.getKey()));
						
						for (DataSnapshot row2 : row.child("alternativas").getChildren()) {
							System.out.println("Troca alternativa: " + row2.getKey());
							Alternativa altAux = new Alternativa(Integer.parseInt(row2.getKey())
																,row2.getValue().toString());
							
							db.getReference("respostas").child(quest_id).child(String.valueOf(quesAux.getSequence()))
							  .child(String.valueOf(altAux.getID()))
							  .addListenerForSingleValueEvent(new ValueEventListener() {
								
								@Override
								public void onDataChange(DataSnapshot arg0) {
									altAux.setResultTotal(arg0.getChildrenCount());							
								}
								
								@Override
								public void onCancelled(DatabaseError arg0) {
									altAux.setResultTotal(0);	
								}
							});
							
							quesAux.addAlternativa(altAux);							
						};
						
						questoes.add(quesAux);
						
					}
					
					returnStatus = 1;
					
				}
				
				@Override
				public void onCancelled(DatabaseError arg0) {
					returnStatus = 2;					
				}
			});		
			
			while (returnStatus == 0) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			long totalParticipantes;
			DecimalFormat df = new DecimalFormat("#.##");
			
			for(Questao q : questoes) {
				
				totalParticipantes = 0;
				
				for(Alternativa a : q.getAlternativas()) {
					totalParticipantes += a.getResultTotal();
				}
				
				q.setParticipantes(totalParticipantes);
				
				if(q.getParticipantes() != 0) {	
					
					for(Alternativa a : q.getAlternativas()) {
						float percent;
						
						if(a.getResultTotal() == 0) {
							percent = 0;
						}
						else{
							percent = Float.parseFloat(String.valueOf(a.getResultTotal())) / Float.parseFloat(String.valueOf(q.getParticipantes()));
						}
						
						percent = Float.parseFloat(df.format(percent*100).replaceAll(",", "."));
						
						a.setResultPercent(percent);
					}	
					
					gerarGrafico(retorno.getId(),q);
					
				}		
				
			}
			
			result.include("quest", retorno);
			result.include("questoes", questoes);
			
		}		
	}
	
	public void gerarGrafico(String questID, Questao questao) {
		
		DefaultPieDataset dataset = new DefaultPieDataset( );
		
		for(Alternativa a : questao.getAlternativas()) {			
			dataset.setValue(a.getTexto(), a.getResultTotal());			
		}
	
	    JFreeChart grafico = ChartFactory.createPieChart(
	       questao.getTexto(),
	       dataset,
	       true,
	       false,
	       false);
	    
	    PiePlot plot = (PiePlot) grafico.getPlot();

        PieSectionLabelGenerator gen = new StandardPieSectionLabelGenerator(
            "{0}: {1} ({2})", new DecimalFormat("0"), new DecimalFormat("0.00%"));
        plot.setLabelGenerator(gen);
        
        Color lightGray = new Color(242, 242, 242);
        
        plot.setLabelOutlinePaint(null);
        plot.setLabelShadowPaint(null);
        plot.setLabelBackgroundPaint(null);
        plot.setBackgroundPaint(lightGray);
        plot.setLabelLinkStyle(PieLabelLinkStyle.STANDARD);
        
        Font labelFont = new Font(plot.getLabelFont().getFontName(), Font.BOLD, 12);
        plot.setLabelFont(labelFont);
        
        Font legendFont = new Font(plot.getLabelFont().getFontName(), Font.BOLD, 14);
        LegendTitle legend = grafico.getLegend();
        legend.setItemFont(legendFont);
	       
	    int width = 800;
	    int height = 600;
	    File pieChart = new File(context.getRealPath("/resources/graphs/") + questID + questao.getSequence() + ".jpeg"); 
	    
	    try {
			ChartUtils.saveChartAsJPEG( pieChart , grafico , width , height );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	      
	}

}
