package br.edu.ifsp.model;

public class Admin {
	
	private String UID;
	private String email;
	
	public Admin (String pUID, String pEmail) {
		this.UID = pUID;
		this.email = pEmail;
	}
	
	public String getUID() {
		return UID;
	}
	public void setUID(String uID) {
		UID = uID;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}	

}
