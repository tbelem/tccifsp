package br.edu.ifsp.util;

public class GlobalValues {
	
	public static String getProjectDirectory () {
		return "C:\\Users\\Tiago\\eclipse-workspace\\TCC\\Survey";
	}

}
